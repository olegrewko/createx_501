# sneakmax-youtube
репозиторий для проекта sneakmax с канала MaxGraph - сайты как страсть
<a href="http://work.maxgraph.ru/test_projects/sneakmax/" target="_blank">Ссылка на хостинг</a>
